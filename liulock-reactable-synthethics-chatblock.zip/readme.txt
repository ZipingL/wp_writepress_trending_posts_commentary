=== LiuLock Synthethics™ Reactable Custom Chatbox Block ===
Requires at least: 6.1
Tags:  Wordpress,Custom,Block,Type,Plugin,React 18,ReadDOM 18,Wordpress,Custom,Block,React,Hooks,Wordpress,Blocks
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Plugin URI: https://github.com/ZIPING-LIU-CORPORATION/liulock-reactable-synthethics-chatblock